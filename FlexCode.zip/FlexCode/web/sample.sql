

--------- CASA ACCOUNT UPLOAD ---------------

 BEFORE STARTING THE CASA ACCOUNT MIGRATION , UPDATE THE NEW FLEXCUBE CIF NUMBER IN STTB_UPLOAD_CUST_ACCOUNT
 
declare
begin
  For I in (select * from sttm_customer  ) Loop
  
    update sttb_upload_cust_account
       set cust_no = I.CUSTOMER_NO
    
     where cust_no = I.EXT_REF_NO;
  
  End Loop;
  commit;
end;

SELECT BRANCH_CODE,COUNT(MAINTENANCE_TYPE)MAINTENANCE_TYPE,UPLOAD_STATUS,SOURCE_CODE
FROM STTB_UPLOAD_MASTER 
WHERE BRANCH_CODE = '003' AND MAINTENANCE_TYPE = 'IADCUSAC' and MAINTENANCE_seq_no in ('100303200057692','100303100003824','100303100010222','100303100006143')
GROUP BY BRANCH_CODE,UPLOAD_STATUS,SOURCE_CODE


SELECT BRANCH_CODE,COUNT(MAINTENANCE_TYPE)MAINTENANCE_TYPE,UPLOAD_STATUS,SOURCE_CODE
FROM STTB_UPLOAD_MASTER 
WHERE BRANCH_CODE = '&BRN' AND MAINTENANCE_TYPE = 'IADCUSAC' and source_code = 'ACCUPLOAD'
GROUP BY BRANCH_CODE,UPLOAD_STATUS,SOURCE_CODE

UPDATE STTB_UPLOAD_MASTER SET UPLOAD_STATUS = 'U' WHERE MAINTENANCE_TYPE = 'IADCUSAC' and UPLOAD_STATUS = 'E' and branch_code = '&brn';

SELECT ERROR_CODE,ERROR_PARAMETERS,COUNT(SOURCE_REF) CNT
FROM CSTB_UPLOAD_EXCEPTION WHERE SOURCE_CODE = 'ACCUPLOAD'  AND BRANCH_CODE = '&BRN' AND ERROR_CODE <> 'ST-SAVE-004'
GROUP BY ERROR_CODE,ERROR_PARAMETERS

SELECT MODE_OF_OPERATION,COUNT(MAINTENANCE_SEQ_NO),JOINT_AC_INDICATOR 
FROM STTB_UPLOAD_CUST_ACCOUNT GROUP BY MODE_OF_OPERATION , JOINT_AC_INDICATOR

--- update for chaning the MODE_OF_OPERATION of Corporate custoemr accounts to J from others.
UPDATE STTB_UPLOAD_CUST_ACCOUNT SET MODE_OF_OPERATION = 'J' WHERE ALT_AC_NO IN (
SELECT DISTINCT SOURCE_REF FROM CSTB_UPLOAD_EXCEPTION WHERE SOURCE_CODE = 'ACCUPLOAD'  AND BRANCH_CODE = '002' AND ERROR_CODE = 'ST-ACC-602'
)

---- update for changing the mode of operation of Single accounts to S
UPDATE STTB_UPLOAD_CUST_ACCOUNT SET MODE_OF_OPERATION = 'S' where WHERE JOINT_AC_INDICATOR = 'S' and branch_code = '&brn';

--- updating the cheque reorder 
SELECT CHECKBOOK_NAME_1, CHEQUE_BOOK_FACILITY , FROM STTM_CUST_ACCOUNT WHERE BRANCH_CODE = '002' AND CHEQUE_BOOK_FACILITY = 'Y'

UPDATE STTB_UPLOAD_CUST_ACCOUNT SET AUTO_REORDER_CHECK_REQUIRED = 'N' WHERE AUTO_REORDER_CHECK_REQUIRED = 'Y' and branch_code = '&brn';

--- updating the location
UPDATE STTB_UPLOAD_CUST_ACCOUNT SET LOCATION = 'KABUL' where  branch_code = '&brn';

---- updating the ac_open_date,no_debit,no_credit,dormant,frozan

update STTB_UPLOAD_CUST_ACCOUNT set
ac_stat_no_dr = 'N',
ac_stat_no_cr = 'N',
ac_stat_block = 'N',
ac_stat_stop_pay = 'N',
ac_stat_dormant = 'N',
ac_stat_frozen = 'N',
dormant_param  = 'N',
ac_open_date = (SELECT TODAY FROM STTM_DATES WHERE BRANCH_CODE = '&BRN')
WHERE BRANCH_CODE = '&BRN'

----------- Updating the start date of linked entities to migration date
UPDATE STTB_UPLOAD_LINKED_ENTITIES SET START_DATE = (SELECT TODAY FROM STTM_DATES WHERE BRANCH_CODE = '&BRN')


---- updating the nomanies to change the minor DOB to major.

select maintenance_seq_no,nominee_dob,is_minor , TRUNC(MONTHS_BETWEEN((select today from sttm_dates where branch_code = '&brn'), nominee_dob))/12   
from sttb_upload_acc_nominees where BRANCH_CODE = '&brn'
and TRUNC(MONTHS_BETWEEN((select today from sttm_dates where branch_code = '&brn'), nominee_dob))/12  < 18

update sttb_upload_acc_nominees set nominee_dob = '1-jan-1985' where maintenance_seq_no in (
select maintenance_seq_no sttb_upload_acc_nominees where BRANCH_CODE = '&brn'
and TRUNC(MONTHS_BETWEEN((select today from sttm_dates where branch_code = '&brn'), nominee_dob))/12  < 18 )

----- updating the address1 in nomanies tables

update sttb_upload_acc_nominees set address1 = 'KABUL' WHERE maintenance_seq_no IN ( select maintenance_seq_no sttb_upload_acc_nominees where BRANCH_CODE = '&brn'
and  IS_MINOR IS NOT NULL  

DECLARE
CURSOR C1 is
select a.account,a.account_branch,a.ccy_cd,sca.cust_ac_no,sca.alt_ac_no,sca.ccy,sca.branch_code
from detb_upload_detail_003 a,bktRUAT.sttm_cust_account sca
where 
a.account = sca.alt_ac_no
and a.account_branch = sca.branch_code
and a.ccy_cd = sca.ccy
and sca.branch_code = '003';

BEGIN
FOR C2 IN C1 
LOOP

UPDATE detb_upload_detail_003 A 
SET A.account = c2.cust_ac_no
WHERE A.account = C2.alt_ac_no 
AND A.account_branch = C2.BRANCH_CODE
and a.ccy_cd = c2.ccy;
--COMMIT;
END LOOP;
END;


DECLARE
CURSOR C1 is
select sca.cust_ac_no,sca.branch_code,sca.alt_ac_no
bkp.ac_stat_no_dr,bkp.ac_stat_no_cr,bkp.ac_stat_block,bkp.ac_stat_stop_pay,bkp.ac_stat_dormant,bkp.ac_stat_frozen,bkp.dormant_param,bkp.ac_open_date
from sttm_cust_account_bkp bkp,sttm_cust_account sca
where 
bkp.alt_ac_no = sca.cust_ac_no
and bkp.branch_code = sca.branch_code
and bkp.ccy = sca.ccy
and sca.branch_code = '&brn';

BEGIN
FOR C2 IN C1 
LOOP

UPDATE sttm_cust_account A 
SET A.ac_stat_no_dr = c2.ac_stat_no_dr,
A.ac_stat_no_dr = c2.ac_stat_no_dr,
A.ac_stat_no_cr = c2.ac_stat_no_cr,
A.ac_stat_block = c2.ac_stat_block,
A.ac_stat_stop_pay = c2.ac_stat_stop_pay,
A.ac_stat_dormant = c2.ac_stat_dormant,
A.ac_stat_frozen = c2.ac_stat_frozen,
A.dormant_param = c2.dormant_param,
A.ac_open_date = c2.ac_open_date
WHERE 
and A.alt_ac_no = C2.alt_ac_no 
AND A.BRANCH_CODE = C2.BRANCH_CODE
and a.ccy_cd = c2.ccy;
--COMMIT;
END LOOP;
END;

